# Importance Sampling

From <https://rahuldave.github.io/posts/importancesampling/>

## Quick start

```bash
# Install uv (if you don't have it)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Run the notebook (installs dependencies automatically)
uvx juv run index.ipynb
```

`juv` reads the PEP 723 metadata inside the notebook and installs
the required packages into an isolated environment.

## Dependencies

- scipy
- numpy
- matplotlib

## License

Educational content from Harvard AM207.
